/* netinfo.c */
void initnetinfo(void);
