/* route.c */
PyObject *netinfo_adddel_route(PyObject *self, PyObject *args, int action);
PyObject *netinfo_add_route(PyObject *self, PyObject *args);
PyObject *netinfo_del_route(PyObject *self, PyObject *args);
